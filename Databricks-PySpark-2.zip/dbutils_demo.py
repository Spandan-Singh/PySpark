# Databricks notebook source
# MAGIC %fs ls

# COMMAND ----------

# MAGIC %fs ls /FileStore/tables

# COMMAND ----------

# MAGIC %fs ls /FileStore/tables/deltaformat

# COMMAND ----------

# MAGIC %fs rm /FileStore/tables/linregdata1.csv

# COMMAND ----------

# MAGIC %fs help

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/default/", recurse=True)

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/deltaformat/", recurse=True)

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/customers.txt")

# COMMAND ----------


