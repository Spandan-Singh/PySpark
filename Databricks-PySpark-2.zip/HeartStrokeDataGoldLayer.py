# Databricks notebook source
silverDF=spark.read.load("/FileStore/tables/silver/", format='parquet')

# silverDF=spark.read.parquet("/FileStore/tables/silver/part-00000-tid-2004629259673028427-1cd8ce03-f22d-4009-91cc-6b3fd5ccd0f0-20-1-c000.snappy.parquet")



# COMMAND ----------

silverDF.printSchema()

# COMMAND ----------

silverDF.show(5)

# COMMAND ----------

silverDF.describe().show()

# COMMAND ----------

from pyspark.ml.feature import Binarizer

# COMMAND ----------

binarizer = Binarizer(inputCol="BMI", outputCol="BodyType", threshold=30.0)


# COMMAND ----------

binarizedDF = binarizer.transform(silverDF)

# COMMAND ----------

binarizedDF.select('BMI', 'BodyType').show(5,False)

# COMMAND ----------

binarizedDF.printSchema()

# COMMAND ----------

from pyspark.ml.feature import Bucketizer
# lets define the age age group splits
splits = [0, 25.0, 50.0, 75.0, 100.0]
bucketizer = Bucketizer(inputCol="age", outputCol="ageGroup", splits=splits)
bucketizedDF = bucketizer.transform(binarizedDF)
bucketizedDF.select('age', 'ageGroup').show(10,False)

# COMMAND ----------

bucketizedDF.printSchema()

# COMMAND ----------

bucketizedDF.show(5)

# COMMAND ----------

from pyspark.ml.feature import StringIndexer
indexers = StringIndexer(inputCols= ['stroke','gender', 'heart_disease', 'smoking_history'], 
                         outputCols=['label', 'gender_indexed', 'heart_disease_indexed', 'smoking_history_indexed'])
strindexedDF = indexers.fit(bucketizedDF).transform(bucketizedDF)
strindexedDF.select('stroke', 'label', 'gender', 'gender_indexed', 'heart_disease', 'heart_disease_indexed', 
                    'smoking_history', 'smoking_history_indexed').show(5, False)

# COMMAND ----------

strindexedDF.printSchema()

# COMMAND ----------

strindexedDF.show(5)

# COMMAND ----------

from pyspark.ml.feature import VectorAssembler

# Create a list of all the variables that are required in features vector
# These features are then further used for training model

features_col = ["diabetes", "hypertension", "BodyType", "ageGroup", 
                "gender_indexed","heart_disease_indexed","smoking_history_indexed"]

# Create the VectorAssembler object

assembler = VectorAssembler(inputCols= features_col, outputCol= "features")
assembledDF = assembler.transform(strindexedDF)
assembledDF.select("features").show(5, False)

# COMMAND ----------

assembledDF.printSchema()

# COMMAND ----------

assembledDF.show(5,False)

# COMMAND ----------

assembledDF.write.save("/FileStore/tables/gold/", format="parquet")
