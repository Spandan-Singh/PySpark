rawstrokeDF = spark.read.format('csv').option("inferSchema", True).option("header", True).option("sep",',').load("/FileStore/tables/bronze/HeartStroke.csv")

rawstrokeDF.show(5, False)

rawstrokeDF.count()

rawstrokeDF.printSchema()

# ## Check missing values
# (For this exercise we will drop all the na values)

from pyspark.sql.functions import isnull, when, count, col

rawstrokeDF.describe().show()

rawstrokeDF.filter(col('smoking_history').isNull()).count()
rawstrokeDF.filter(col('BMI').isNull()).count()

rawstrokeDF.filter(col('smoking_history').isNull()).select(count('*')).show()
rawstrokeDF.filter(col('BMI').isNull()).select(count('*')).show()

rawstrokeDF = rawstrokeDF.na.drop()

# Check if the null value still exist

rawstrokeDF.select([count(when(isnull(c), c)).alias(c) for c in rawstrokeDF.columns]).show()

rawstrokeDF.show(5, False)

rawstrokeDF.count()

rawstrokeDF.describe().show()

# ## Check and confirm the data type of each column

rawstrokeDF.printSchema()

# The variable values for any supervised ML algorithm has to be of type double. Let us convert the columns "diabetes", "hypertension" and target varaible "stroke" data type into type double

from pyspark.sql.types import DoubleType

intcols = ["diabetes", "hypertension"]
for col_name in intcols:
    strokeDF = rawstrokeDF.withColumn(col_name, col(col_name).cast(DoubleType()))

strokeDF = rawstrokeDF.withColumn("diabetes", col("diabetes").cast(DoubleType())).withColumn("hypertension", col("hypertension").cast(DoubleType()))


strokeDF.write.save("/FileStore/tables/silver/", format="parquet")

# strokeDF.write.parquet("<path>")
strokeDF.write.save("/FileStore/tables/default/")
strokeDF.write.save("/FileStore/tables/deltaformat/", format="delta")




