#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import findspark
findspark.init()
import pyspark

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Python Linear Regression example").getOrCreate()

from pyspark.ml.regression import LinearRegression
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StandardScaler
from pyspark.ml import Pipeline
from pyspark.sql.functions import *

data = spark.read.load("linregdata1.csv", format="csv", sep=",", inferSchema="true", header="true")
data.printSchema()

data.describe().show()

features = ["temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity"]

lr_data = data.select(col("energy_output").alias("label"), *features)
lr_data.printSchema()

lr_data.show()

(training, test) = lr_data.randomSplit([.7, .3])

# VectorAssembler is a transformer that combines a given list of columns into a single vector column.

vectorAssembler = VectorAssembler(inputCols=features, outputCol="unscaled_features")

# StandardScaler transforms a dataset of Vector rows, normalizing each feature to have unit standard deviation or zero mean.
# Uses 'withStd' by default i.e. scales the data to unit standard deviation.

standardScaler = StandardScaler(inputCol="unscaled_features", outputCol="features")

lr = LinearRegression(maxIter=10, regParam=.02)

mystages = [vectorAssembler, standardScaler, lr]
mypipeline = Pipeline(stages=mystages)

model = mypipeline.fit(training)

type(model)

prediction_df = model.transform(test)

prediction_df.show(truncate=False)

prediction_df.select("label","prediction").show(truncate=False)

from pyspark.ml.evaluation import RegressionEvaluator
eval = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")

rmse = eval.evaluate(prediction_df)
print("RMSE: %.3f" % rmse)

mse = eval.evaluate(prediction_df, {eval.metricName: "mse"})
print("MSE: %.3f" % mse)

mae = eval.evaluate(prediction_df, {eval.metricName: "mae"})
print("MAE: %.3f" % mae)

r2 = eval.evaluate(prediction_df, {eval.metricName: "r2"})
print("r2: %.3f" %r2)

